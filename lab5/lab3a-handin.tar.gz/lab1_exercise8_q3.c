//I can't run this file 
//so I just do exercise8_ q3 in kern/moniter.c  mon_backtrace()

#include "kern/printf.c"


int main(){
	int x = 1, y = 3, z = 4;
	cprintf("x %d, y %x, z %d\n", x, y, z);
}

